#include <stdio.h>
#include <stdlib.h>

int main (){
    int n, calc;
    printf("digite um numero: ");
    scanf("%d", &n);
    calc = n*n*n;
    printf("cubo: %d", calc);
}

