#include <stdio.h>
#include <stdlib.h>

int main (){
    int n, calc;
    printf("digite para saber o dobro: ");
    scanf("%d", &n);
    calc = n+n;
    printf("dobro: %d", calc);
}
