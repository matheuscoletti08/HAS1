#include <stdio.h>
#include <stdlib.h>

int main (){
    int n, calc;
    printf("digite o numero: ");
    scanf("%d", &n);
    calc = n*n;
    printf("quadrado: %d", calc);
}
